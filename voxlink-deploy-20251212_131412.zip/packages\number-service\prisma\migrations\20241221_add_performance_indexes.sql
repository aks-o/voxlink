-- Performance optimization indexes for virtual numbers

-- Index for country and area code searches (most common search pattern)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_country_area 
ON "VirtualNumber" (country_code, area_code) 
WHERE status = 'AVAILABLE';

-- Index for owner queries with status
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_owner_status 
ON "VirtualNumber" (owner_id, status, created_at DESC) 
WHERE owner_id IS NOT NULL;

-- Index for phone number lookups (unique constraint already exists, but explicit index for clarity)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_phone 
ON "VirtualNumber" (phone_number);

-- Index for status and creation date (for admin queries)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_status_created 
ON "VirtualNumber" (status, created_at DESC);

-- Index for geographic searches
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_location 
ON "VirtualNumber" (country_code, region, city) 
WHERE status = 'AVAILABLE';

-- Index for feature-based searches using GIN for array operations
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_features 
ON "VirtualNumber" USING GIN (features) 
WHERE status = 'AVAILABLE';

-- Index for price range searches
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_pricing 
ON "VirtualNumber" (monthly_rate, setup_fee) 
WHERE status = 'AVAILABLE';

-- Composite index for complex search queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_search_composite 
ON "VirtualNumber" (country_code, area_code, status, monthly_rate, created_at DESC);

-- Index for number reservations
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_number_reservations_expires 
ON "NumberReservation" (expires_at) 
WHERE expires_at > NOW();

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_number_reservations_user 
ON "NumberReservation" (user_id, created_at DESC);

-- Index for usage records (time-series data)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_usage_records_number_timestamp 
ON "UsageRecord" (number_id, timestamp DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_usage_records_timestamp_type 
ON "UsageRecord" (timestamp DESC, event_type);

-- Partial index for active numbers only
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_virtual_numbers_active 
ON "VirtualNumber" (owner_id, created_at DESC) 
WHERE status IN ('ACTIVE', 'SUSPENDED');

-- Index for porting requests
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_porting_requests_status_created 
ON "PortingRequest" (status, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_porting_requests_user 
ON "PortingRequest" (user_id, status, created_at DESC);

-- Index for number configurations
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_number_configurations_number 
ON "NumberConfiguration" (number_id);

-- Add statistics for query planner
ANALYZE "VirtualNumber";
ANALYZE "NumberReservation";
ANALYZE "UsageRecord";
ANALYZE "PortingRequest";
ANALYZE "NumberConfiguration";

-- Create materialized view for search performance (optional)
CREATE MATERIALIZED VIEW IF NOT EXISTS available_numbers_summary AS
SELECT 
    country_code,
    area_code,
    region,
    city,
    COUNT(*) as available_count,
    MIN(monthly_rate) as min_monthly_rate,
    MAX(monthly_rate) as max_monthly_rate,
    AVG(monthly_rate) as avg_monthly_rate,
    array_agg(DISTINCT unnest(features)) as all_features
FROM "VirtualNumber" 
WHERE status = 'AVAILABLE'
GROUP BY country_code, area_code, region, city;

-- Index on the materialized view
CREATE INDEX IF NOT EXISTS idx_available_numbers_summary_location 
ON available_numbers_summary (country_code, area_code);

-- Refresh the materialized view (should be done periodically)
REFRESH MATERIALIZED VIEW available_numbers_summary;