-- Add regional pricing tables
CREATE TABLE regional_pricing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  region VARCHAR(10) NOT NULL,
  currency VARCHAR(3) NOT NULL,
  pricing_config JSONB NOT NULL,
  tax_config JSONB NOT NULL,
  effective_from TIMESTAMP NOT NULL DEFAULT NOW(),
  effective_until TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE volume_discounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  region VARCHAR(10) NOT NULL,
  tier_name VARCHAR(50) NOT NULL,
  min_usage INTEGER NOT NULL,
  max_usage INTEGER,
  discount_percent DECIMAL(5,2) NOT NULL,
  usage_type VARCHAR(20) NOT NULL CHECK (usage_type IN ('MINUTES', 'SMS', 'MONTHLY_SPEND')),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX idx_regional_pricing_region_effective ON regional_pricing(region, effective_from, effective_until);
CREATE INDEX idx_volume_discounts_region_tier ON volume_discounts(region, tier_name);

-- Insert India pricing configuration
INSERT INTO regional_pricing (region, currency, pricing_config, tax_config) VALUES 
('IN', 'INR', '{
  "setupFee": 0,
  "monthlyBase": 19900,
  "inboundCallPerMinute": 50,
  "outboundCallPerMinute": 75,
  "smsInbound": 10,
  "smsOutbound": 25,
  "voicemailPerMessage": 500,
  "callForwardingPerMinute": 25
}', '{
  "rate": 0.18,
  "type": "GST",
  "cgst": 0.09,
  "sgst": 0.09,
  "igst": 0.18
}');

-- Insert US pricing configuration (existing)
INSERT INTO regional_pricing (region, currency, pricing_config, tax_config) VALUES 
('US', 'USD', '{
  "setupFee": 500,
  "monthlyBase": 1000,
  "inboundCallPerMinute": 2,
  "outboundCallPerMinute": 3,
  "smsInbound": 1,
  "smsOutbound": 2,
  "voicemailPerMessage": 5,
  "callForwardingPerMinute": 1
}', '{
  "rate": 0.08,
  "type": "SALES_TAX"
}');

-- Insert India volume discounts
INSERT INTO volume_discounts (region, tier_name, min_usage, max_usage, discount_percent, usage_type) VALUES 
('IN', 'STARTER', 0, 1000, 0.00, 'MINUTES'),
('IN', 'BUSINESS', 1001, 5000, 15.00, 'MINUTES'),
('IN', 'ENTERPRISE', 5001, 20000, 30.00, 'MINUTES'),
('IN', 'ENTERPRISE_PLUS', 20001, NULL, 50.00, 'MINUTES'),
('IN', 'SMS_BULK', 1000, NULL, 20.00, 'SMS');